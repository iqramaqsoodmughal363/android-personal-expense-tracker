# 📱 Personal Expense Tracker — Android Studio Project

Ek fully functional Android expense tracker app — Java + XML mein bani hui.  
Yeh app **sabhi Android versions** par chalti hai — chahe phone purana ho ya naya.

---

## ✅ Android Version Compatibility

| Android Version | API Level | Support |
|---|---|---|
| Android 5.0 Lollipop | API 21 | ✅ Supported |
| Android 5.1 Lollipop | API 22 | ✅ Supported |
| Android 6.0 Marshmallow | API 23 | ✅ Supported |
| Android 7.0 / 7.1 Nougat | API 24–25 | ✅ Supported |
| Android 8.0 / 8.1 Oreo | API 26–27 | ✅ Supported |
| Android 9.0 Pie | API 28 | ✅ Supported |
| Android 10 | API 29 | ✅ Supported |
| Android 11 | API 30 | ✅ Supported |
| Android 12 / 12L | API 31–32 | ✅ Supported |
| Android 13 | API 33 | ✅ Supported |
| Android 14 | API 34 | ✅ Supported (Target) |

> **Minimum:** Android 5.0 (API 21) — aaj ke 99% se zyada devices cover ho jaate hain.

### Compatibility ke liye kya kiya gaya hai

- `ContextCompat.getColor()` use kiya gaya hai (API 23 se neeche `getColor()` crash karta tha)
- `android:windowLightStatusBar` sirf API 23+ ke liye alag `values-v23/themes.xml` mein rakha gaya
- `getResources().getColor(id, theme)` ki jagah safe wala `ContextCompat` version use kiya
- SQLite — kisi bhi Android version par kaam karta hai, koi internet nahi chahiye

---

## 🚀 Android Studio Mein Kaise Kholein

1. **ZIP extract** karein kisi bhi folder mein
2. **Android Studio** kholein *(Hedgehog 2023.1.1 ya newer recommended)*
3. **"Open"** pe click karein → `android-expense-tracker` folder select karein
4. **"Trust Project"** pe click karein jab pooche
5. **Gradle Sync** hone ka wait karein  
   *(Pehli baar internet lagega — sab dependencies automatically download hoti hain)*
6. Android device connect karein ya emulator chalayein
7. Green ▶ **Run** button dabayein

---

## ✨ App Features

### 🏠 Home Screen
- Total balance card (green)
- Income aur Expense ka alag summary
- Recent 10 transactions ki list
- **+** FAB button se naya transaction add karein
- Transaction pe long-press karein delete karne ke liye

### 📊 Analytics Screen
- Category-wise **Donut Pie Chart** (MPAndroidChart)
- Har category ka percentage aur amount
- Color-coded legend

### 📋 History Screen
- Sabhi transactions ek jagah
- **Search bar** — category ya note se dhundein
- **Filter chips** — All / Income / Expenses
- Long-press se delete

### ➕ Add Transaction Screen
- **Income / Expense toggle** button
- Amount enter karein
- Category select karein (spinner)
- **Date Picker** se date chunein
- Optional note add karein

---

## 📁 Project Structure

```
android-expense-tracker/
├── app/
│   └── src/main/
│       ├── java/com/expense/tracker/
│       │   ├── MainActivity.java           ← Bottom navigation + fragment host
│       │   ├── HomeFragment.java           ← Dashboard screen
│       │   ├── AnalyticsFragment.java      ← Pie chart screen
│       │   ├── HistoryFragment.java        ← Search + filter screen
│       │   ├── AddTransactionActivity.java ← Transaction form
│       │   ├── database/
│       │   │   └── DatabaseHelper.java     ← SQLite CRUD (singleton)
│       │   ├── model/
│       │   │   └── Transaction.java        ← Data model (POJO)
│       │   └── adapter/
│       │       └── TransactionAdapter.java ← RecyclerView adapter
│       └── res/
│           ├── layout/                     ← Sabhi XML layouts
│           ├── values/                     ← Colors, strings, themes (API 21+)
│           ├── values-v23/                 ← API 23+ ke liye theme override
│           ├── color/                      ← Bottom nav color selector
│           ├── drawable/                   ← Icons aur shapes
│           ├── menu/                       ← Bottom navigation menu
│           └── mipmap-anydpi-v26/          ← Adaptive launcher icon (API 26+)
├── gradle/wrapper/
│   └── gradle-wrapper.properties          ← Gradle 8.4
├── build.gradle                           ← Project-level build config
├── app/build.gradle                       ← App module config (AGP 8.2.2)
├── gradle.properties
├── settings.gradle
└── README.md
```

---

## 📦 Dependencies

| Library | Version | Kaam |
|---|---|---|
| Material Components | 1.11.0 | Cards, FAB, Chips, BottomNavigationView |
| MPAndroidChart | v3.1.0 | Pie chart (JitPack se) |
| RecyclerView | 1.3.2 | Transaction list |
| ConstraintLayout | 2.1.4 | Layouts |
| AndroidX Core | 1.12.0 | ContextCompat aur backward compatibility |

---

## ⚙️ Build Configuration

| Setting | Value |
|---|---|
| Package Name | `com.expense.tracker` |
| Min SDK | **API 21** (Android 5.0) |
| Target SDK | **API 34** (Android 14) |
| Compile SDK | API 34 |
| Build Tools (AGP) | 8.2.2 |
| Gradle | 8.4 |
| Java Version | Java 8 |
| ViewBinding | Enabled |

---

## 💾 Data Storage

- **SQLite database** — poora data device mein locally save hota hai
- Internet ki koi zaroorat nahi
- App delete karne par data bhi delete ho jaata hai
- Database file: `expense_tracker.db`

---

## ❓ Common Issues & Solutions

**Gradle sync fail ho raha hai?**
→ Internet connection check karein. Pehli baar MPAndroidChart JitPack se download hoti hai.

**App install nahi ho raha?**
→ Device ka Android version 5.0 se kam hai. `minSdk 21` set hai.

**Emulator mein blank screen aa raha hai?**
→ Emulator API 21+ ka use karein. Cold Boot karein.

**Build error: "Could not resolve"?**
→ `settings.gradle` mein JitPack repository already add hai. Bas sync dobara karein.

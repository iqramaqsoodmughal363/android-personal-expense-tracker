package com.expense.tracker;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.expense.tracker.adapter.TransactionAdapter;
import com.expense.tracker.database.DatabaseHelper;
import com.expense.tracker.databinding.FragmentHomeBinding;
import com.expense.tracker.model.Transaction;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private DatabaseHelper db;
    private TransactionAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        db = DatabaseHelper.getInstance(requireContext());

        setupRecyclerView();
        setupFab();

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void setupRecyclerView() {
        adapter = new TransactionAdapter(requireContext(), new ArrayList<>());
        binding.rvRecentTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvRecentTransactions.setAdapter(adapter);
        binding.rvRecentTransactions.setNestedScrollingEnabled(false);

        adapter.setOnItemLongClickListener(transaction ->
            new AlertDialog.Builder(requireContext())
                .setTitle("Delete Transaction")
                .setMessage("Remove this transaction?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.deleteTransaction(transaction.getId());
                    loadData();
                })
                .setNegativeButton("Cancel", null)
                .show()
        );
    }

    private void setupFab() {
        binding.fabAddTransaction.setOnClickListener(v ->
            startActivity(new Intent(requireActivity(), AddTransactionActivity.class))
        );
    }

    private void loadData() {
        List<Transaction> all = db.getAllTransactions();
        double income  = db.getTotalByType("income");
        double expense = db.getTotalByType("expense");
        double balance = income - expense;

        binding.tvBalance.setText(String.format("$%.2f", balance));
        binding.tvTotalIncome.setText(String.format("$%.2f", income));
        binding.tvTotalExpense.setText(String.format("$%.2f", expense));

        List<Transaction> recent = all.size() > 10 ? all.subList(0, 10) : all;
        adapter.updateList(recent);

        if (recent.isEmpty()) {
            binding.rvRecentTransactions.setVisibility(View.GONE);
            binding.tvEmptyState.setVisibility(View.VISIBLE);
        } else {
            binding.rvRecentTransactions.setVisibility(View.VISIBLE);
            binding.tvEmptyState.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

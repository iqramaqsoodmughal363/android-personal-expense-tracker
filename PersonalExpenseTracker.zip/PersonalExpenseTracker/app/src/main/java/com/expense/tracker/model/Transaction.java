package com.expense.tracker.model;

public class Transaction {
    private int id;
    private String type; // "income" or "expense"
    private double amount;
    private String note;
    private String category;
    private String date; // YYYY-MM-DD

    public Transaction() {}

    public Transaction(int id, String type, double amount, String note, String category, String date) {
        this.id = id;
        this.type = type;
        this.amount = amount;
        this.note = note;
        this.category = category;
        this.date = date;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public boolean isIncome() { return "income".equals(type); }
}

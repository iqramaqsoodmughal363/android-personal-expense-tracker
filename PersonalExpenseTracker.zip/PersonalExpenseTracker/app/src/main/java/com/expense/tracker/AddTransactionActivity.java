package com.expense.tracker;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.expense.tracker.database.DatabaseHelper;
import com.expense.tracker.databinding.ActivityAddTransactionBinding;
import com.expense.tracker.model.Transaction;

import java.util.Calendar;

public class AddTransactionActivity extends AppCompatActivity {

    private ActivityAddTransactionBinding binding;
    private DatabaseHelper db;

    private boolean isIncome = false; // default: expense
    private int selectedYear, selectedMonth, selectedDay;

    private static final String[] EXPENSE_IDS = {
        "food", "transport", "shopping", "entertainment",
        "health", "bills", "education", "other_expense"
    };
    private static final String[] EXPENSE_NAMES = {
        "Food", "Transport", "Shopping", "Entertainment",
        "Health", "Bills", "Education", "Other"
    };

    private static final String[] INCOME_IDS = {
        "salary", "business", "investment", "freelance", "gift", "other_income"
    };
    private static final String[] INCOME_NAMES = {
        "Salary", "Business", "Investment", "Freelance", "Gift", "Other"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddTransactionBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        db = DatabaseHelper.getInstance(this);

        // Default date = today
        Calendar cal = Calendar.getInstance();
        selectedYear  = cal.get(Calendar.YEAR);
        selectedMonth = cal.get(Calendar.MONTH);
        selectedDay   = cal.get(Calendar.DAY_OF_MONTH);
        updateDateButton();

        setupTypeToggle();
        updateCategorySpinner();
        setupDatePicker();
        setupSaveButton();
        setupBackButton();
    }

    private void setupTypeToggle() {
        binding.btnExpense.setOnClickListener(v -> {
            if (!isIncome) return; // already selected
            isIncome = false;
            updateToggleStyle();
            updateCategorySpinner();
        });
        binding.btnIncome.setOnClickListener(v -> {
            if (isIncome) return; // already selected
            isIncome = true;
            updateToggleStyle();
            updateCategorySpinner();
        });
        updateToggleStyle(); // set initial style
    }

    private void updateToggleStyle() {
        if (isIncome) {
            // Income active (green)
            binding.btnIncome.setBackgroundResource(R.drawable.toggle_item_selected_green);
            binding.btnIncome.setTextColor(ContextCompat.getColor(this, android.R.color.white));
            // Expense inactive (transparent)
            binding.btnExpense.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            binding.btnExpense.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        } else {
            // Expense active (red)
            binding.btnExpense.setBackgroundResource(R.drawable.toggle_item_selected_red);
            binding.btnExpense.setTextColor(ContextCompat.getColor(this, android.R.color.white));
            // Income inactive (transparent)
            binding.btnIncome.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            binding.btnIncome.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        }
    }

    private void updateCategorySpinner() {
        String[] names = isIncome ? INCOME_NAMES : EXPENSE_NAMES;
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, names
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerCategory.setAdapter(adapter);
    }

    private void setupDatePicker() {
        binding.btnDate.setOnClickListener(v -> {
            DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    selectedYear  = year;
                    selectedMonth = month;
                    selectedDay   = dayOfMonth;
                    updateDateButton();
                },
                selectedYear, selectedMonth, selectedDay
            );
            dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
            dialog.show();
        });
    }

    private void updateDateButton() {
        String[] months = {"Jan","Feb","Mar","Apr","May","Jun",
                           "Jul","Aug","Sep","Oct","Nov","Dec"};
        binding.btnDate.setText(
            months[selectedMonth] + " " + selectedDay + ", " + selectedYear
        );
    }

    private void setupSaveButton() {
        binding.btnSave.setOnClickListener(v -> {
            String amountStr = binding.etAmount.getText() != null
                ? binding.etAmount.getText().toString().trim() : "";

            if (amountStr.isEmpty()) {
                Toast.makeText(this, "Please enter an amount", Toast.LENGTH_SHORT).show();
                return;
            }

            double amount;
            try {
                amount = Double.parseDouble(amountStr);
                if (amount <= 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Enter a valid positive amount", Toast.LENGTH_SHORT).show();
                return;
            }

            int pos = binding.spinnerCategory.getSelectedItemPosition();
            String[] ids = isIncome ? INCOME_IDS : EXPENSE_IDS;
            if (pos < 0 || pos >= ids.length) {
                Toast.makeText(this, "Please select a category", Toast.LENGTH_SHORT).show();
                return;
            }
            String categoryId = ids[pos];
            String type = isIncome ? "income" : "expense";
            String note = binding.etNote.getText() != null
                ? binding.etNote.getText().toString().trim() : "";
            String date = String.format("%04d-%02d-%02d",
                selectedYear, selectedMonth + 1, selectedDay);

            Transaction t = new Transaction();
            t.setType(type);
            t.setAmount(amount);
            t.setNote(note);
            t.setCategory(categoryId);
            t.setDate(date);

            long result = db.addTransaction(t);
            if (result != -1) {
                Toast.makeText(this, "Saved!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Failed to save. Try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupBackButton() {
        binding.btnBack.setOnClickListener(v -> finish());
    }
}

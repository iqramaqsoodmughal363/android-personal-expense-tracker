package com.expense.tracker.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.expense.tracker.R;
import com.expense.tracker.model.Transaction;
import androidx.core.content.ContextCompat;

import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    public interface OnItemLongClickListener {
        void onItemLongClick(Transaction transaction);
    }

    private List<Transaction> transactions;
    private final Context context;
    private OnItemLongClickListener longClickListener;

    public TransactionAdapter(Context context, List<Transaction> transactions) {
        this.context = context;
        this.transactions = transactions;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaction t = transactions.get(position);

        holder.tvCategory.setText(getCategoryDisplayName(t.getCategory()));

        String subtitle = (t.getNote() != null && !t.getNote().isEmpty())
            ? t.getNote() : formatDate(t.getDate());
        holder.tvNote.setText(subtitle);
        holder.tvDate.setText(formatDate(t.getDate()));

        String amountText = String.format("$%.2f", t.getAmount());
        if (t.isIncome()) {
            holder.tvAmount.setText("+" + amountText);
            holder.tvAmount.setTextColor(ContextCompat.getColor(context, R.color.income_color));
        } else {
            holder.tvAmount.setText("-" + amountText);
            holder.tvAmount.setTextColor(ContextCompat.getColor(context, R.color.expense_color));
        }

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(t);
            }
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    public void updateList(List<Transaction> newList) {
        this.transactions = newList;
        notifyDataSetChanged();
    }

    private String getCategoryDisplayName(String id) {
        switch (id) {
            case "salary":        return "Salary";
            case "business":      return "Business";
            case "investment":    return "Investment";
            case "freelance":     return "Freelance";
            case "gift":          return "Gift";
            case "other_income":  return "Other Income";
            case "food":          return "Food";
            case "transport":     return "Transport";
            case "shopping":      return "Shopping";
            case "entertainment": return "Entertainment";
            case "health":        return "Health";
            case "bills":         return "Bills";
            case "education":     return "Education";
            case "other_expense": return "Other Expense";
            default:              return id;
        }
    }

    private String formatDate(String isoDate) {
        if (isoDate == null || isoDate.length() < 10) return isoDate;
        try {
            String[] parts = isoDate.split("-");
            String[] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
            int m = Integer.parseInt(parts[1]) - 1;
            return months[m] + " " + parts[2];
        } catch (Exception e) {
            return isoDate;
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final MaterialCardView cardTransaction;
        final TextView tvCategory;
        final TextView tvNote;
        final TextView tvAmount;
        final TextView tvDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardTransaction = itemView.findViewById(R.id.card_transaction);
            tvCategory      = itemView.findViewById(R.id.tv_category);
            tvNote          = itemView.findViewById(R.id.tv_note);
            tvAmount        = itemView.findViewById(R.id.tv_amount);
            tvDate          = itemView.findViewById(R.id.tv_date);
        }
    }
}

package com.expense.tracker;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.expense.tracker.database.DatabaseHelper;
import com.expense.tracker.databinding.FragmentAnalyticsBinding;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;

import java.util.ArrayList;
import java.util.List;

public class AnalyticsFragment extends Fragment {

    private FragmentAnalyticsBinding binding;
    private DatabaseHelper db;

    private static final int[] SLICE_COLORS = {
        Color.parseColor("#FF453A"),
        Color.parseColor("#4C9AFF"),
        Color.parseColor("#FF6B9D"),
        Color.parseColor("#B24BF3"),
        Color.parseColor("#00E5A0"),
        Color.parseColor("#FF9F43"),
        Color.parseColor("#00B4D8"),
        Color.parseColor("#8E8E93"),
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentAnalyticsBinding.inflate(inflater, container, false);
        db = DatabaseHelper.getInstance(requireContext());
        setupPieChart();
        loadData();
        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void setupPieChart() {
        binding.pieChart.setUsePercentValues(true);
        binding.pieChart.getDescription().setEnabled(false);
        binding.pieChart.setDrawHoleEnabled(true);
        binding.pieChart.setHoleColor(Color.TRANSPARENT);
        binding.pieChart.setHoleRadius(55f);
        binding.pieChart.setTransparentCircleRadius(61f);
        binding.pieChart.setDrawCenterText(true);
        binding.pieChart.setCenterText("Expenses");
        binding.pieChart.setCenterTextSize(16f);
        binding.pieChart.setCenterTextColor(Color.parseColor("#1C1C1E"));
        binding.pieChart.setRotationEnabled(true);
        binding.pieChart.setHighlightPerTapEnabled(true);
        binding.pieChart.getLegend().setEnabled(false);
        binding.pieChart.animateY(1200, Easing.EaseInOutQuad);
    }

    private void loadData() {
        List<Object[]> data = db.getCategoryWiseExpenses();

        if (data.isEmpty()) {
            binding.pieChart.setVisibility(View.GONE);
            binding.tvNoData.setVisibility(View.VISIBLE);
            binding.legendContainer.setVisibility(View.GONE);
            return;
        }

        binding.pieChart.setVisibility(View.VISIBLE);
        binding.tvNoData.setVisibility(View.GONE);
        binding.legendContainer.setVisibility(View.VISIBLE);

        List<PieEntry> entries = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        double totalExpense = 0;

        for (Object[] row : data) totalExpense += (Double) row[1];

        for (int i = 0; i < data.size(); i++) {
            String categoryId = (String) data.get(i)[0];
            double amount = (Double) data.get(i)[1];
            entries.add(new PieEntry((float) amount, getCategoryName(categoryId)));
            colors.add(SLICE_COLORS[i % SLICE_COLORS.length]);
        }

        PieDataSet dataSet = new PieDataSet(entries, "Expenses");
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);
        dataSet.setColors(colors);
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(11f);

        PieData pieData = new PieData(dataSet);
        pieData.setValueFormatter(new PercentFormatter(binding.pieChart));
        binding.pieChart.setData(pieData);
        binding.pieChart.invalidate();

        // Build legend rows
        binding.legendContainer.removeAllViews();
        for (int i = 0; i < data.size(); i++) {
            String categoryId = (String) data.get(i)[0];
            double amount = (Double) data.get(i)[1];
            double pct = (amount / totalExpense) * 100;
            int color = SLICE_COLORS[i % SLICE_COLORS.length];

            View row = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_legend, binding.legendContainer, false);

            // Draw a colored circle for the dot
            View dotView = row.findViewById(R.id.legend_dot);
            GradientDrawable oval = new GradientDrawable();
            oval.setShape(GradientDrawable.OVAL);
            oval.setColor(color);
            dotView.setBackground(oval);

            ((TextView) row.findViewById(R.id.legend_label)).setText(getCategoryName(categoryId));
            ((TextView) row.findViewById(R.id.legend_pct)).setText(String.format("%.1f%%", pct));
            ((TextView) row.findViewById(R.id.legend_amount)).setText(
                String.format("$%.2f", amount)
            );

            binding.legendContainer.addView(row);
        }
    }

    private String getCategoryName(String id) {
        switch (id) {
            case "food":          return "Food";
            case "transport":     return "Transport";
            case "shopping":      return "Shopping";
            case "entertainment": return "Entertainment";
            case "health":        return "Health";
            case "bills":         return "Bills";
            case "education":     return "Education";
            case "other_expense": return "Other";
            case "salary":        return "Salary";
            case "business":      return "Business";
            case "investment":    return "Investment";
            case "freelance":     return "Freelance";
            case "gift":          return "Gift";
            case "other_income":  return "Other Income";
            default:              return id;
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

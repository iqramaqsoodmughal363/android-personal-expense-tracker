package com.expense.tracker;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.expense.tracker.adapter.TransactionAdapter;
import com.expense.tracker.database.DatabaseHelper;
import com.expense.tracker.databinding.FragmentHistoryBinding;
import com.expense.tracker.model.Transaction;

import java.util.ArrayList;
import java.util.List;

public class HistoryFragment extends Fragment {

    private FragmentHistoryBinding binding;
    private DatabaseHelper db;
    private TransactionAdapter adapter;
    private List<Transaction> allTransactions = new ArrayList<>();
    private String filterType = "all"; // "all", "income", "expense"

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentHistoryBinding.inflate(inflater, container, false);
        db = DatabaseHelper.getInstance(requireContext());

        setupRecyclerView();
        setupSearch();
        setupChips();

        return binding.getRoot();
    }

    @Override
    public void onResume() {
        super.onResume();
        allTransactions = db.getAllTransactions();
        applyFilter();
    }

    private void setupRecyclerView() {
        adapter = new TransactionAdapter(requireContext(), new ArrayList<>());
        binding.rvTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvTransactions.setAdapter(adapter);

        adapter.setOnItemLongClickListener(transaction ->
            new AlertDialog.Builder(requireContext())
                .setTitle("Delete Transaction")
                .setMessage("Remove this transaction?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    db.deleteTransaction(transaction.getId());
                    allTransactions = db.getAllTransactions();
                    applyFilter();
                })
                .setNegativeButton("Cancel", null)
                .show()
        );
    }

    private void setupSearch() {
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFilter();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private void setupChips() {
        // Use ChipGroup single-selection listener
        binding.chipGroupFilter.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chip_income) {
                filterType = "income";
            } else if (id == R.id.chip_expense) {
                filterType = "expense";
            } else {
                filterType = "all";
            }
            applyFilter();
        });
    }

    private void applyFilter() {
        String query = binding.etSearch.getText() != null
            ? binding.etSearch.getText().toString().toLowerCase().trim()
            : "";

        List<Transaction> filtered = new ArrayList<>();
        for (Transaction t : allTransactions) {
            boolean typeMatch = filterType.equals("all") || t.getType().equals(filterType);
            boolean searchMatch = query.isEmpty()
                || t.getCategory().toLowerCase().contains(query)
                || (t.getNote() != null && t.getNote().toLowerCase().contains(query))
                || String.valueOf(t.getAmount()).contains(query);
            if (typeMatch && searchMatch) filtered.add(t);
        }

        adapter.updateList(filtered);
        binding.tvCount.setText(filtered.size() + " transaction" + (filtered.size() != 1 ? "s" : ""));

        if (filtered.isEmpty()) {
            binding.rvTransactions.setVisibility(View.GONE);
            binding.tvNoResults.setVisibility(View.VISIBLE);
        } else {
            binding.rvTransactions.setVisibility(View.VISIBLE);
            binding.tvNoResults.setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}

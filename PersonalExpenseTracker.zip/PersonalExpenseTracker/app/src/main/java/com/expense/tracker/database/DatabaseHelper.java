package com.expense.tracker.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.expense.tracker.model.Transaction;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "expense_tracker.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE_TRANSACTIONS = "transactions";
    public static final String COL_ID = "id";
    public static final String COL_TYPE = "type";
    public static final String COL_AMOUNT = "amount";
    public static final String COL_NOTE = "note";
    public static final String COL_CATEGORY = "category";
    public static final String COL_DATE = "date";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE =
            "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
            COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COL_TYPE + " TEXT NOT NULL, " +
            COL_AMOUNT + " REAL NOT NULL, " +
            COL_NOTE + " TEXT DEFAULT '', " +
            COL_CATEGORY + " TEXT NOT NULL, " +
            COL_DATE + " TEXT NOT NULL)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        onCreate(db);
    }

    /** Insert a new transaction. Returns the new row ID, or -1 on failure. */
    public long addTransaction(Transaction t) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_TYPE, t.getType());
        values.put(COL_AMOUNT, t.getAmount());
        values.put(COL_NOTE, t.getNote() != null ? t.getNote() : "");
        values.put(COL_CATEGORY, t.getCategory());
        values.put(COL_DATE, t.getDate());
        long id = db.insert(TABLE_TRANSACTIONS, null, values);
        db.close();
        return id;
    }

    /** Return all transactions, newest first. */
    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
            TABLE_TRANSACTIONS, null, null, null, null, null,
            COL_DATE + " DESC, " + COL_ID + " DESC"
        );
        if (cursor.moveToFirst()) {
            do {
                list.add(cursorToTransaction(cursor));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return list;
    }

    /** Delete a transaction by its ID. */
    public boolean deleteTransaction(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_TRANSACTIONS, COL_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    /** Sum of amounts for a given type ("income" or "expense"). */
    public double getTotalByType(String type) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT SUM(" + COL_AMOUNT + ") FROM " + TABLE_TRANSACTIONS +
            " WHERE " + COL_TYPE + "=?",
            new String[]{type}
        );
        double total = 0;
        if (cursor.moveToFirst() && !cursor.isNull(0)) {
            total = cursor.getDouble(0);
        }
        cursor.close();
        db.close();
        return total;
    }

    /**
     * Returns category-wise expense totals for the pie chart.
     * Each Object[] has: [0] = category String, [1] = total Double
     */
    public List<Object[]> getCategoryWiseExpenses() {
        List<Object[]> result = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
            "SELECT " + COL_CATEGORY + ", SUM(" + COL_AMOUNT + ") AS total" +
            " FROM " + TABLE_TRANSACTIONS +
            " WHERE " + COL_TYPE + "='expense'" +
            " GROUP BY " + COL_CATEGORY +
            " ORDER BY total DESC",
            null
        );
        if (cursor.moveToFirst()) {
            do {
                result.add(new Object[]{cursor.getString(0), cursor.getDouble(1)});
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return result;
    }

    private Transaction cursorToTransaction(Cursor c) {
        return new Transaction(
            c.getInt(c.getColumnIndexOrThrow(COL_ID)),
            c.getString(c.getColumnIndexOrThrow(COL_TYPE)),
            c.getDouble(c.getColumnIndexOrThrow(COL_AMOUNT)),
            c.getString(c.getColumnIndexOrThrow(COL_NOTE)),
            c.getString(c.getColumnIndexOrThrow(COL_CATEGORY)),
            c.getString(c.getColumnIndexOrThrow(COL_DATE))
        );
    }
}
